var files_dup =
[
    [ "antena.c", "antena_8c.html", "antena_8c" ],
    [ "antena.h", "antena_8h.html", "antena_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "matriz.c", "matriz_8c.html", "matriz_8c" ],
    [ "matriz.h", "matriz_8h.html", "matriz_8h" ]
];