var searchData=
[
  ['antena_0',['Antena',['../struct_antena.html',1,'Antena'],['../antena_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2',1,'Antena:&#160;antena.h']]],
  ['antena_2ec_1',['antena.c',['../antena_8c.html',1,'']]],
  ['antena_2eh_2',['antena.h',['../antena_8h.html',1,'']]],
  ['auxrantenas_3',['auxrAntenas',['../antena_8c.html#a95eef017973172f510d032bc882e2053',1,'antena.c']]]
];
