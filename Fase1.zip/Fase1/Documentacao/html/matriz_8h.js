var matriz_8h =
[
    [ "Node", "struct_node.html", "struct_node" ],
    [ "Node", "matriz_8h.html#a3b09f37e675bcd48a01bf22155996872", null ],
    [ "carregarMatrizDoFicheiro", "matriz_8h.html#a9d66c32dc5785c33196976b9b9c8e43e", null ],
    [ "exibirMatriz", "matriz_8h.html#aba3864945dc2745df349ff8d16243f54", null ],
    [ "gerarEfeitosNefastos", "matriz_8h.html#a5ea6087f0b529841e75090f478056e67", null ],
    [ "listarNefastos", "matriz_8h.html#a78a6ce8e44d392a2c309e13677d40dd1", null ]
];