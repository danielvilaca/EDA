var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['matriz_2ec_2',['matriz.c',['../matriz_8c.html',1,'']]],
  ['matriz_2eh_3',['matriz.h',['../matriz_8h.html',1,'']]]
];
