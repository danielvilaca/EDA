var searchData=
[
  ['gerarefeitosnefastos_0',['gerarEfeitosNefastos',['../matriz_8c.html#a5ea6087f0b529841e75090f478056e67',1,'gerarEfeitosNefastos(Antena *listaAntenas, char matriz[][100], int linhas, int colunas):&#160;matriz.c'],['../matriz_8h.html#a5ea6087f0b529841e75090f478056e67',1,'gerarEfeitosNefastos(Antena *listaAntenas, char matriz[][100], int linhas, int colunas):&#160;matriz.c']]]
];
