var files_dup =
[
    [ "grafo.c", "grafo_8c.html", "grafo_8c" ],
    [ "grafo.h", "grafo_8h.html", "grafo_8h" ],
    [ "main.c", "main_8c.html", null ],
    [ "utils.c", "utils_8c.html", "utils_8c" ],
    [ "utils.h", "utils_8h.html", "utils_8h" ]
];