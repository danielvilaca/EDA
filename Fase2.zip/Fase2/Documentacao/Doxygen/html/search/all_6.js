var searchData=
[
  ['listarcaminhos_0',['listarCaminhos',['../grafo_8c.html#a3aa60bd76c822db53ccc812f1707e0b5',1,'listarCaminhos(Grafo *g, int origem, int destino):&#160;grafo.c'],['../grafo_8h.html#a3aa60bd76c822db53ccc812f1707e0b5',1,'listarCaminhos(Grafo *g, int origem, int destino):&#160;grafo.c']]],
  ['listarcaminhosaux_1',['listarCaminhosAux',['../grafo_8c.html#a1be91eccd6e8691af9f33ddf1186eaaa',1,'grafo.c']]]
];
