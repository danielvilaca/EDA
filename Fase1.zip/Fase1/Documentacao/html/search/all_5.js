var searchData=
[
  ['inserirantena_0',['inserirAntena',['../antena_8c.html#acc0269270f879978a2b329a200244697',1,'inserirAntena(Antena **aux, char freq, int linha, int coluna):&#160;antena.c'],['../antena_8h.html#acc0269270f879978a2b329a200244697',1,'inserirAntena(Antena **aux, char freq, int linha, int coluna):&#160;antena.c']]],
  ['inserirnefasto_1',['inserirNefasto',['../matriz_8c.html#a14d59b78779d5b1b5ab79aac7c3eb43a',1,'matriz.c']]]
];
