var searchData=
[
  ['freq_0',['freq',['../struct_antena.html#acbb0ceb3114405ec0fd07f67b79bd3e5',1,'Antena']]]
];
