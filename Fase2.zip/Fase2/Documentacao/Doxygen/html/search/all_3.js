var searchData=
[
  ['dfs_0',['dfs',['../grafo_8c.html#a562457b89adc87f2389c61373499fd83',1,'dfs(Grafo *g, int start_id):&#160;grafo.c'],['../grafo_8h.html#a562457b89adc87f2389c61373499fd83',1,'dfs(Grafo *g, int start_id):&#160;grafo.c']]],
  ['dfs_5fvisit_1',['dfs_visit',['../grafo_8c.html#a9d360aab7800fed0523977436f7d689b',1,'grafo.c']]]
];
