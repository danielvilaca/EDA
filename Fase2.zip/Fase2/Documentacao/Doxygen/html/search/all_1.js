var searchData=
[
  ['bfs_0',['bfs',['../grafo_8c.html#a59a62882be97d2e4daf143a5585b10af',1,'bfs(Grafo *g, int start_id):&#160;grafo.c'],['../grafo_8h.html#a59a62882be97d2e4daf143a5585b10af',1,'bfs(Grafo *g, int start_id):&#160;grafo.c']]]
];
