var searchData=
[
  ['linha_0',['linha',['../struct_antena.html#a2913fa9623f812bffff810528877ee24',1,'Antena::linha'],['../struct_node.html#aed29de4c5d116b3f4a9880896d0023d3',1,'Node::linha']]]
];
