var matriz_8c =
[
    [ "carregarMatrizDoFicheiro", "matriz_8c.html#ae03a71ace65214ff61d91e0338498fc2", null ],
    [ "exibirMatriz", "matriz_8c.html#aba3864945dc2745df349ff8d16243f54", null ],
    [ "gerarEfeitosNefastos", "matriz_8c.html#a5ea6087f0b529841e75090f478056e67", null ],
    [ "inserirNefasto", "matriz_8c.html#a14d59b78779d5b1b5ab79aac7c3eb43a", null ],
    [ "listarNefastos", "matriz_8c.html#a37b39a41a7b261b151581be51bc1dd2b", null ]
];