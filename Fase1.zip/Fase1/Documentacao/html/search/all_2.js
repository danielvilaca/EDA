var searchData=
[
  ['exibirmatriz_0',['exibirMatriz',['../matriz_8c.html#aba3864945dc2745df349ff8d16243f54',1,'exibirMatriz(Antena *listaAntenas, int linhas, int colunas):&#160;matriz.c'],['../matriz_8h.html#aba3864945dc2745df349ff8d16243f54',1,'exibirMatriz(Antena *listaAntenas, int linhas, int colunas):&#160;matriz.c']]]
];
