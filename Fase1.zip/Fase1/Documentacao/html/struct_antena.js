var struct_antena =
[
    [ "coluna", "struct_antena.html#ad28f77663b945c81f26e84c1b62cb63f", null ],
    [ "freq", "struct_antena.html#acbb0ceb3114405ec0fd07f67b79bd3e5", null ],
    [ "linha", "struct_antena.html#a2913fa9623f812bffff810528877ee24", null ],
    [ "next", "struct_antena.html#ae518c9afee14b875ac030364762e23ba", null ]
];