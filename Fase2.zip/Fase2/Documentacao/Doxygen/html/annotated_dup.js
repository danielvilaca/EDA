var annotated_dup =
[
    [ "adj", "structadj.html", null ],
    [ "grafo", "structgrafo.html", null ],
    [ "vertice", "structvertice.html", null ]
];