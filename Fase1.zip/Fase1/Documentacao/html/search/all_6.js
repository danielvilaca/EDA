var searchData=
[
  ['libertarantenas_0',['libertarAntenas',['../antena_8c.html#a66ea723ccc8f6e107b0c215c4b2dd28f',1,'libertarAntenas(Antena *aux):&#160;antena.c'],['../antena_8h.html#a66ea723ccc8f6e107b0c215c4b2dd28f',1,'libertarAntenas(Antena *aux):&#160;antena.c']]],
  ['linha_1',['linha',['../struct_antena.html#a2913fa9623f812bffff810528877ee24',1,'Antena::linha'],['../struct_node.html#aed29de4c5d116b3f4a9880896d0023d3',1,'Node::linha']]],
  ['listarantenas_2',['listarAntenas',['../antena_8h.html#a2a18909c27210e17ff28c6b4c8aa29a7',1,'antena.h']]],
  ['listarnefastos_3',['listarNefastos',['../matriz_8c.html#a37b39a41a7b261b151581be51bc1dd2b',1,'listarNefastos(Node *aux):&#160;matriz.c'],['../matriz_8h.html#a78a6ce8e44d392a2c309e13677d40dd1',1,'listarNefastos(Node *lista):&#160;matriz.c']]]
];
