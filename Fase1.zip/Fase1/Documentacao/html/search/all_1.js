var searchData=
[
  ['carregarmatrizdoficheiro_0',['carregarMatrizDoFicheiro',['../matriz_8c.html#ae03a71ace65214ff61d91e0338498fc2',1,'carregarMatrizDoFicheiro(const char *nomeFicheiro, Antena **aux, int *linhas, int *colunas):&#160;matriz.c'],['../matriz_8h.html#a9d66c32dc5785c33196976b9b9c8e43e',1,'carregarMatrizDoFicheiro(const char *nomeFicheiro, Antena **listaAntenas, int *linhas, int *colunas):&#160;matriz.c']]],
  ['coluna_1',['coluna',['../struct_antena.html#ad28f77663b945c81f26e84c1b62cb63f',1,'Antena::coluna'],['../struct_node.html#a42f897b88b42ed9fc526b5794fcf934f',1,'Node::coluna']]],
  ['criarantena_2',['criarAntena',['../antena_8c.html#a00a386a23b9f361d1f4c1cb0e735ca5d',1,'criarAntena(char freq, int linha, int coluna):&#160;antena.c'],['../antena_8h.html#a00a386a23b9f361d1f4c1cb0e735ca5d',1,'criarAntena(char freq, int linha, int coluna):&#160;antena.c']]]
];
