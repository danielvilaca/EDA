var searchData=
[
  ['adicionaaresta_0',['adicionaAresta',['../grafo_8c.html#a66d9d6385ec027346ffc2c39ad307ad4',1,'adicionaAresta(Grafo *g, int orig, int dest):&#160;grafo.c'],['../grafo_8h.html#a66d9d6385ec027346ffc2c39ad307ad4',1,'adicionaAresta(Grafo *g, int orig, int dest):&#160;grafo.c']]],
  ['adicionavertice_1',['adicionaVertice',['../grafo_8c.html#ad0e922e8998db2ce1b829ee52ed583a7',1,'adicionaVertice(Grafo *g, int x, int y, char freq):&#160;grafo.c'],['../grafo_8h.html#ad0e922e8998db2ce1b829ee52ed583a7',1,'adicionaVertice(Grafo *g, int x, int y, char freq):&#160;grafo.c']]]
];
