var annotated_dup =
[
    [ "Antena", "struct_antena.html", "struct_antena" ],
    [ "Node", "struct_node.html", "struct_node" ]
];