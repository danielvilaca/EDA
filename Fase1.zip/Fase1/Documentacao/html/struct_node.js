var struct_node =
[
    [ "coluna", "struct_node.html#a42f897b88b42ed9fc526b5794fcf934f", null ],
    [ "linha", "struct_node.html#aed29de4c5d116b3f4a9880896d0023d3", null ],
    [ "next", "struct_node.html#af67b110ca1a258b793bf69d306929b22", null ]
];