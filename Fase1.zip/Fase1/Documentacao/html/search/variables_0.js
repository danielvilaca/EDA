var searchData=
[
  ['coluna_0',['coluna',['../struct_antena.html#ad28f77663b945c81f26e84c1b62cb63f',1,'Antena::coluna'],['../struct_node.html#a42f897b88b42ed9fc526b5794fcf934f',1,'Node::coluna']]]
];
