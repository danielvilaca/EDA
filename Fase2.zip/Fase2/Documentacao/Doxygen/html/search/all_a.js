var searchData=
[
  ['vertice_0',['vertice',['../structvertice.html',1,'']]]
];
