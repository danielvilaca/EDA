var searchData=
[
  ['adj_0',['adj',['../structadj.html',1,'']]]
];
