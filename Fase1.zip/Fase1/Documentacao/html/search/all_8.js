var searchData=
[
  ['next_0',['next',['../struct_antena.html#ae518c9afee14b875ac030364762e23ba',1,'Antena::next'],['../struct_node.html#af67b110ca1a258b793bf69d306929b22',1,'Node::next']]],
  ['node_1',['Node',['../struct_node.html',1,'Node'],['../matriz_8h.html#a3b09f37e675bcd48a01bf22155996872',1,'Node:&#160;matriz.h']]]
];
